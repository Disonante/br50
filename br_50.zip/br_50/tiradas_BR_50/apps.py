from django.apps import AppConfig


class TiradasBr50Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tiradas_BR_50'


